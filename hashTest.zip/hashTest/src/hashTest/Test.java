package hashTest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
public class Test {
	public static void main(String[] args) throws Exception{
		HashMap<String,String> map= new HashMap<String,String>();
		ArrayList<HashMap<String,String>> list= new ArrayList<HashMap<String,String>>();
		map.put("no","3");
		map.put("title","test3");
		list.add(map);
		map = new HashMap<String,String>();
		map.put("no","1");
		map.put("title","test1");
		list.add(map);
		map=new HashMap<String, String>();
		map.put("no","2");
		map.put("title","test2");
		list.add(map);
		System.out.println(list);
		
		MapComparator comp= new MapComparator("no");
		Collections.sort(list,comp);
		System.out.println(list);
	}

}
class MapComparator implements Comparator<HashMap<String,String>>{
	private final String key;
	public MapComparator(String key) {
		this.key=key;
	}
	public int compare(HashMap<String,String> first, HashMap<String,String> second) {
		int result = first.get(key).compareTo(second.get(key));
		return result;
	}
}