import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	private BufferedReader reader;
	private ServerSocket server;
	private Socket socket;
	public void start() {
		try {
			server = new ServerSocket(12345);
			System.out.println("server가 활성화");
			while(true) {
				socket = server.accept();
				reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
				getMessage();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
				try {
					if(reader != null) reader.close();
					if(socket != null) socket.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
	}
	private void getMessage() {
		// TODO Auto-generated method stub
		
			try {
				while(true) {
				System.out.println("클라이언트: "+reader.readLine());
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("클라이언트가 연결을 끊었습니다.");
			}
		}
		
	}
	