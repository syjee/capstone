import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
	private PrintWriter writer;
	private Socket socket;
	public void start() {
		try {
			socket = new Socket("127.0.0.1",12345);
			System.out.println("서버 접속");
			writer = new PrintWriter(socket.getOutputStream(),true);
			Scanner scan = new Scanner(System.in);
			while (true) {
				writer.println(scan.next());
			}
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
