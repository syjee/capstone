import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class scaner {
	public static void main(String[] args) throws UnknownHostException, IOException
	{
		int timeout=9000;
		String subnet="172.30.1";
		for(int i=1;i<255;i++) {
			String host = subnet + "." + i;
			if(InetAddress.getByName(host).isReachable(timeout)){
				System.out.println(host+" is reachable");
				
			}
		}
		

	}
	}
